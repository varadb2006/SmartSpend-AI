from typing import List
import pandas as pd
import io
from fastapi import APIRouter, Depends,UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.user import User
from app.models.transaction import Transaction
from app.schemas.transaction import TransactionCreate, TransactionResponse
from app.api.deps import get_current_user
from app.services.categorizer import train_categorizer, predict_categories
from app.services.anamoly_detector import flag_anomalies
from app.services.forecaster import forecast_next_month
from pydantic import BaseModel

router = APIRouter()

class CategoryUpdate(BaseModel):
    category: str

@router.post("/", response_model=TransactionResponse)
def create_transaction( transaction_in : TransactionCreate, db:Session = Depends(get_db), current_user : User = Depends(get_current_user)):
    print(f"✓ Transaction received: {transaction_in.description} | {transaction_in.amount}")
    
    final_category = transaction_in.category
    if not final_category or final_category.strip() == "" or final_category.strip().lower() == "uncategorized":
        ml_df = pd.DataFrame([{"description": transaction_in.description, "amount": float(transaction_in.amount)}])
        predicted_cat = predict_categories(ml_df)[0]
        final_category = predicted_cat
        print(f"✓ Predicted category: {final_category}")

    transaction_data = transaction_in.model_dump()
    transaction_data["category"] = final_category
    
    db_transaction = Transaction( **transaction_data, user_id = current_user.id)
    db.add(db_transaction)
    db.commit()
    db.refresh(db_transaction)
    print("✓ Database updated with new transaction")
    return db_transaction

@router.get("/", response_model=List[TransactionResponse])
def get_transactions(db: Session = Depends(get_db), current_user:  User = Depends(get_current_user), skip : int = 0, limit: int =  100):
    transactions = db.query(Transaction).filter(Transaction.user_id == current_user.id).order_by(Transaction.id.desc()).offset(skip).limit(limit).all()
    return transactions

@router.post("/upload")
async def upload_transactions(file: UploadFile = File(...), db : Session = Depends(get_db), current_user : User = Depends(get_current_user)):
    contents = await file.read()
    filename = file.filename.lower()

    try:
        if filename.endswith(".csv"):
            df = pd.read_csv(io.BytesIO(contents))
        elif filename.endswith(".xlsx"):
            df = pd.read_excel(io.BytesIO(contents))
        else :
            raise HTTPException(status_code=400, detail="Only .csv and .xlsx filea are allowed")

    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error reading file: {str(e)}")

    required_columns = {"Date", "Description", "Amount", "Transaction_Type"}
    if not required_columns.issubset(df.columns):
        raise HTTPException( status_code=400, detail=f"Missing required columns. File must contain: {', '.join(required_columns)}")

    ml_df = pd.DataFrame({"description" : df["Description"].astype(str), "amount" : pd.to_numeric(df["Amount"], errors='coerce').fillna(0.0)})
    predicted_categories = predict_categories(ml_df)
    transaction_Added =0
    for index, row in df.iterrows():
        provided_category = row.get("Category")
        if pd.isna(provided_category) or str(provided_category).strip() == "":
            final_category = predicted_categories[index]
        else:
            final_category= str(provided_category)

        db_transaction = Transaction(
            user_id=current_user.id,
            transaction_date=str(row["Date"]),
            description=str(row["Description"]),
            amount=float(row["Amount"]),
            transaction_type=str(row["Transaction_Type"]).upper(),
            category=final_category
        )
        db.add(db_transaction)
        transaction_Added += 1

    db.commit()
    
    return {
        "message": "File processed successfully", 
        "total_processed": transaction_Added
    }

@router.post("/train-categorizer")
def trigger_model_training(db: Session = Depends(get_db),current_user: User = Depends(get_current_user)):
    print("✓ Model training started")
    transactions = db.query(Transaction).filter(Transaction.user_id == current_user.id).all()
    if not transactions:
        raise HTTPException(status_code=400, detail="No transactions found to train on.")
    
    df = pd.DataFrame([{"description": t.description,"amount": t.amount,"category": t.category} for t in transactions])
    print(f"✓ Dataset size = {len(df)}")
    
    success = train_categorizer(df)
    if not success:
        raise HTTPException(status_code=400, detail="Not enough categorized data to train the model. Minimum 10 categorized transactions required.")

    print("✓ Model trained successfully")
    
    uncategorized_txs = [t for t in transactions if not t.category or t.category.strip() == "" or t.category.strip().lower() == "uncategorized"]
    print(f"✓ Uncategorized rows = {len(uncategorized_txs)}")
    
    if uncategorized_txs:
        print("✓ Predicting categories...")
        uncat_df = pd.DataFrame([{"description": t.description, "amount": t.amount} for t in uncategorized_txs])
        preds = predict_categories(uncat_df)
        
        for idx, t in enumerate(uncategorized_txs):
            t.category = preds[idx]
        
        db.commit()
        print(f"✓ {len(uncategorized_txs)} categories predicted")
        print("✓ Database updated")

    return {"message": "XGBoost categorizer trained successfully!"}

@router.post("/detect-anomalies")
def trigger_anomaly_detection(db: Session = Depends(get_db),current_user: User = Depends(get_current_user)):
    print("✓ Anomaly detection started")
    transactions = db.query(Transaction).filter(
        Transaction.user_id == current_user.id,
        Transaction.transaction_type.in_(["debit", "DEBIT", "expense", "EXPENSE", "Debit", "Expense"])
    ).all()
    print(f"✓ Transactions found for anomaly detection: {len(transactions)}")
    
    if len(transactions) < 5:
        print("✓ Not enough transactions, returning 0 anomalies")
        return {"message": "Need at least 5 expenses to run anomaly detection.", "total_analyzed": len(transactions), "anomalies_found": 0}
        
    df = pd.DataFrame([{"amount": t.amount} for t in transactions])
    anomaly_flags = flag_anomalies(df)
    anomalies_found = 0
    for idx, transaction in enumerate(transactions):
        transaction.is_anomaly = anomaly_flags[idx]
        if anomaly_flags[idx]:
            anomalies_found += 1

    db.commit()
    print(f"✓ Anomaly detection complete. {anomalies_found} anomalies found.")

    return {"message": "Anomaly detection complete","total_analyzed": len(transactions), "anomalies_found": anomalies_found }

@router.get("/forecast")
def get_spending_forecast(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    transactions = db.query(Transaction).filter(
        Transaction.user_id == current_user.id,
        Transaction.transaction_type.in_(["debit", "DEBIT", "expense", "EXPENSE", "Debit", "Expense"])
    ).all()
    
    if not transactions:
        return {"forecasted_amount": 0.0, "message": "No expense data available."}

    df = pd.DataFrame([{"transaction_date": t.transaction_date, "amount": t.amount} for t in transactions])
    predicted_amount = forecast_next_month(df)

    if predicted_amount == 0.0:
        return {"forecasted_amount": 0.0, "message": "Need at least 3 months of historical data to generate a reliable forecast."}

    return {"forecasted_amount": predicted_amount, "message": "Forecast generated successfully."}

@router.put("/{transaction_id}/category")
def update_transaction_category(
    transaction_id: int, 
    update_data: CategoryUpdate, 
    db: Session = Depends(get_db)
):
    transaction = db.query(Transaction).filter(Transaction.id == transaction_id).first()
    
    if not transaction:
        raise HTTPException(status_code=404, detail="Transaction not found")
        
    transaction.category = update_data.category
    db.commit()
    db.refresh(transaction)
    
    return {
        "message": "Category updated successfully", 
        "transaction_id": transaction.id,
        "description": transaction.description,
        "updated_category": transaction.category
    }